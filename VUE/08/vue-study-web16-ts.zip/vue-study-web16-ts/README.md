# ts+vue实践
- ts核心语法
- ts+vue开发实践
- 装饰器原理
- vue-property-decorator源码解析

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
