<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
  </div>
</template>

<script lang="ts">
import { Prop, Vue } from 'vue-property-decorator';

// 目标：返回组件构造函数
function Component(options: any) {
  return function(target: any) {
    // 返回组件构造函数即可
    return Vue.extend(options)
  }
}

@Component({
  props: {
    msg: String
  }
})
export default class HelloWorld extends Vue {
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
